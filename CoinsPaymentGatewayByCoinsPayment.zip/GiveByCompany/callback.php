<?php

    include("../../lib/config.php");

	// $fp = fopen('response.txt', 'a');
	// fwrite($fp, '['.date('Y-m-d h:i:s').'] '.json_encode($_REQUEST)."\n");
	// fclose($fp);

	 // Fill these in with the information from your CoinPayments.net account. 
    /*$cp_merchant_id = '017392a478cb6640658c7aa9c3602c3c'; 
    $cp_ipn_secret = '8R8lM6uqrSdUmKxS2f5xgcWDojRjZW'; 
    $cp_debug_email = 'autotradecryptoupdates@gmail.com'; */
    $cp_merchant_id = '769752dbdeb71a1a556f8c2f1efca3fd'; 
    $cp_ipn_secret = 'TroTra999!'; 
    $cp_debug_email = 'info@earnmyshop.com'; 




    function errorAndDie($error_msg) { 
        global $cp_debug_email; 
        if (!empty($cp_debug_email)) { 
            $report = 'Error: '.$error_msg."\n\n"; 
            $report .= "POST Data\n\n"; 
            foreach ($_POST as $k => $v) { 
                $report .= "|$k| = |$v|\n"; 
            } 
            mail($cp_debug_email, 'CoinPayments IPN Error', $report); 
        } 
        die('IPN Error: '.$error_msg); 
    } 

    if (!isset($_POST['ipn_mode']) || $_POST['ipn_mode'] != 'hmac') { 
        errorAndDie('IPN Mode is not HMAC'); 
    } 

    if (!isset($_SERVER['HTTP_HMAC']) || empty($_SERVER['HTTP_HMAC'])) { 
        errorAndDie('No HMAC signature sent.'); 
    } 

    $request = file_get_contents('php://input'); 
    if ($request === FALSE || empty($request)) { 
        errorAndDie('Error reading POST data'); 
    } 

    if (!isset($_POST['merchant']) || $_POST['merchant'] != trim($cp_merchant_id)) { 
        errorAndDie('No or incorrect Merchant ID passed'); 
    } 

    $hmac = hash_hmac("sha512", $request, trim($cp_ipn_secret)); 
    if (!hash_equals($hmac, $_SERVER['HTTP_HMAC'])) { 
    //if ($hmac != $_SERVER['HTTP_HMAC']) { <-- Use this if you are running a version of PHP below 5.6.0 without the hash_equals function 
        errorAndDie('HMAC signature does not match'); 
    } 
     
    // HMAC Signature verified at this point, load some variables. 

    $txn_id = $_POST['txn_id']; 
    $withdrawId = $_POST['id'];
    $item_name = $_POST['item_name']; 
    $item_number = $_POST['item_number']; 
    //$amount1 = floatval($_POST['amount1']); 
    //$amount2 = floatval($_POST['amount2']); 
    $amount = floatval($_POST['amount']); 
    $address = $_POST['address'];
    //$currency1 = $_POST['currency1']; 
    //$currency2 = $_POST['currency2']; 
    $currency = $_POST['currency'];
    $status = intval($_POST['status']); 
    $status_text = $_POST['status_text']; 
    $ipn_type = $_POST['ipn_type'];
    if($ipn_type=='withdrawal'){
        $rand=uniqid(rand(1000000000,9999999999), true);
        $received_confirms = $_POST['received_confirms'];
        $date = date('Y-m-d H:i:s');
    
        $callback = json_encode($_POST);
        
        $withfrawdata = mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM withdraw_request WHERE txnId = '".$withdrawId."'"));
        $txnId = $withfrawdata['txnId'];
        $withstatus = $withfrawdata['status'];
        $request_amount = $withfrawdata['request_amount'];
        $user_ids = $withfrawdata['user_id'];
        mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO coinpayjson SET data='$callback', txnId = '".$withdrawId."', updated = '".$date."'");
        
        if($withstatus==0){
            
            
        
            //These would normally be loaded from your database, the most common way is to pass the Order ID through the 'custom' POST field. 
            $data = mysqli_fetch_assoc(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM coinpayment_ipn WHERE txn_id = '".$withdrawId."'"));
        
            if(count($data)){
            	$order_currency = $data['currency']; 
            	$order_total = $data['amount']; 
            }

            //depending on the API of your system, you may want to check and see if the transaction ID $txn_id has already been handled before at this point 
        
            // Check the original currency to make sure the buyer didn't change it. 
            /*if ($currency != $order_currency) { 
                errorAndDie('Original currency mismatch!'); 
            }  */   
             
            // Check amount against order total 
            /*if ($amount1 < $order_total) { 
                errorAndDie('Amount is less than order total!'); 
            }*/
    
            if ($status >= 100 || $status == 2) { 
                /*$transaction_charge1=($request_amount*0)/100;
                $subamounts=$request_amount-$transaction_charge1;
                $tr_per=40;
                $fourty=$subamounts*$tr_per/100;
                $sixty=$subamounts-$fourty;*/
                // payment is complete or queued for nightly payout, success
                
                /********* OXONI COIN RATE **********/
                /*$curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => 'https://ico.oxoni.io/api/token-exchange?value=1',
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'GET',
                ));
                $response = curl_exec($curl);
                curl_close($curl);
                $cresults = json_decode($response,true);
                $ratess = $cresults['USDT'];*/
                /********* OXONI COIN RATE END **********/
                /*if($ratess!='' || $ratess!=0){
                    $conversion = $fourty/$ratess;
                }else{
                    $rate=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT coin FROM coin_management WHERE id='1'"));
                    $ratess=$rate['coin'];
                    $conversion=$fourty*$ratess;
                }*/
                mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE withdraw_request SET status = '1', admin_remark = '".$status_text."', admin_response_date='".date('Y-m-d')."' WHERE txnId = '".$withdrawId."' ");
                mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment_ipn SET callback = '".$callback."', status_code = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$withdrawId."' ");
                
                $dates = date('Y-m-d');
                $urls="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
                /*mysqli_query($GLOBALS["___mysqli_ston"], "update coin_e_wallet set amount=(amount+$conversion) where user_id='$user_ids'");
                mysqli_query($GLOBALS["___mysqli_ston"], "insert into credit_debit (`transaction_no`,`user_id`,`credit_amt`,`debit_amt`,`admin_charge`,`receiver_id`,`sender_id`,`receive_date`,`ttype`,`TranDescription`,`Cause`,`Remark`,`invoice_no`,`product_name`,`status`,`ewallet_used_by`,`current_url`) 
                values('$rand','$user_ids','$conversion','0','0','$user_ids','$user_ids','$dates','Withdrawal Fund','Withdrawal Fund by $user_ids','$request_amount','$ratess','$rand','$fourty','0','Oxoni Wallet','$urls')");
               */
                
            } else if ($status < 0) {
                
                mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount+$request_amount) where user_id='$user_ids'");
                mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`,`current_url`) 
                VALUES (NULL, '$rand', '$user_ids', '$request_amount', '0', '0', '$user_ids', '$user_ids', '$date', 'Withdrawal Cancelled', 'Withdrawal Request Cancelled', '0', 'Withdrawal Request Cancelled', '$rand', 'Withdrawal Request Cancelled', '0', '$withdrawId','$urls')");
                
                
                mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE withdraw_request SET status = '2', admin_remark = '".$status_text."', admin_response_date='".date('Y-m-d')."' WHERE txnId = '".$withdrawId."' ");
                //payment error, this is usually final but payments will sometimes be reopened if there was no exchange rate conversion or with seller consent 
                mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment_ipn SET callback = '".$callback."', status_code = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$withdrawId."' ");
            } else { 
                //payment is pending, you can optionally add a note to the order page 
                 mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment_ipn SET callback = '".$callback."', status_code = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$withdrawId."' ");
            } 
        
            die('IPN OK'); 
        }
    }
	
	
<?php
// Method to handle IPN response
public function handleAPI(Request $req)
{
    // Step 1: Get the raw POST data
    $raw_post_data = file_get_contents('php://input');  // Get the raw POST data sent by CoinPayments
    $hmac_header = $_SERVER['HTTP_HMAC'] ?? ''; // Retrieve the HMAC header from the request

    // Step 2: Verify HMAC signature
    $hmac_calculated = hash_hmac("sha512", $raw_post_data, $this->privateKey); // Calculate HMAC using the raw data and your private key
    if ($hmac_header !== $hmac_calculated) { // Check if the calculated HMAC matches the one sent in the header
        return response()->json(['status' => 'error', 'message' => 'Invalid HMAC signature'], 400); // Return error if HMAC is invalid
    }

    // Step 3: Process IPN data
    $params = json_decode($raw_post_data, true); // Decode the JSON data into an associative array

    // Step 4: Validate IPN response with CoinPayments
    $response = $this->client->post('https://www.coinpayments.net/api/', [
        'json' => [
            'version' => 1,
            'key' => $this->publicKey,
            'cmd' => 'validate_ipn',
            'req' => $params,
        ]
    ]);

    $validationResult = json_decode($response->getBody()->getContents(), true); // Decode the validation response
    if ($validationResult['error'] !== 'ok') { // Check if the validation was successful
        return response()->json(['status' => 'error', 'message' => 'IPN validation failed: ' . $validationResult['error']], 400); // Return error if validation fails
    }

    // Step 5: Handle the payment based on its status
    if ($params['status'] >= 100 || $params['status'] == 2) { // Check if the payment is complete
        // Step 6: Record the payment in your database
        $result = DB::table('tbl_payment')->insert([ // Insert payment data into the tbl_payment table
            'user_id' => $params['user_id'],
            'payment' => $params['amount'],
            'transaction' => $params['txn_id'],
            'level' => 1,
        ]);

        if ($result) { // If the insert was successful
            // Update the user's status and other related data
            DB::table('tbl_register')->where('id', $params['user_id'])->update([
                'status' => '1',
                'position' => $params['position'],
                'parent_id' => $params['parent_id'],
            ]);

            return response()->json(['status' => 'success', 'message' => 'Payment recorded successfully']); // Return success message
        }

        return response()->json(['status' => 'error', 'message' => 'Failed to insert payment data']); // Return error if insert fails
    }

    return response()->json(['status' => 'error', 'message' => 'Payment not completed']); // Handle case where payment is not complete
}




?>
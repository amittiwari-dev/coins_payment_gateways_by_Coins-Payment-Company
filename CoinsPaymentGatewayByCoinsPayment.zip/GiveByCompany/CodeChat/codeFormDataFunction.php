<?php
public function paymentData(Request $req)
{
    // Step 1: Check if the payment amount is above the minimum threshold
    if ($req->payment > 11) {
        // Step 2: Check if a payment has already been made for this user and level
        $result1 = DB::table('tbl_payment')->where('user_id', $req->id)->where('level', 1)->first();

        // Step 3: Retrieve user data
        $dataResult = DB::table('tbl_register')->where('id', $req->id)->first();
        $positionInfo = $this->getDataUser($dataResult->sopnser_id); // Get user position info

        // Step 4: If no payment record exists, prepare to create a new payment request
        if (!$result1) {
            // Prepare payment request
            $reqData = [
                'amount' => $req->payment,
                'currency1' => 'USDT.TRC20', // Currency for payment
                'currency2' => 'USDT.TRC20', // Currency to receive
                'buyer_email' => 'payment@gmail.com', // Replace with dynamic buyer email if needed
                'user_id' => $req->id, // User ID
                'position' => $positionInfo['position'], // Position data
                'parent_id' => $positionInfo['parent_id'], // Parent ID
                'ipn_url' => route('handle-payment'), // IPN URL
                'success_url' => route('payment.success'), // URL to redirect on success
                'merchant' => $this->merchantId, // Merchant ID, if required
                // 'cancel_url' => route('payment.cancel'), // Uncomment if you have a cancel URL
            ];
            
            // Step 5: Call the payment API
            $response = $this->api_call_payment->CreateTransaction($reqData);
            
            // Step 6: Check for errors in the response
            if (isset($response['error']) && $response['error'] === 'ok') {
                // Redirect to the payment gateway if successful
                return redirect($response['result']['checkout_url']);
            } else {
                // Handle errors
                return redirect('payment')->with('msg', 'Error processing payment: ' . $response['error']);
            }
        } else {
            // If a payment record already exists
            return redirect('payment')->with('msg', 'Payment Already Done!');
        }
    } else {
        // If the payment amount is below the minimum threshold
        return redirect('payment')->with('msg', 'Minimum payment is $12');
    }
}





?>
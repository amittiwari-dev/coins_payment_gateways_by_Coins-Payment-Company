<?php
session_start();
include("header.php");
$idd=$f['user_id']; 
$date=date('Y-m-d');
//$amount=$_REQUEST['amountf'];
/*$amount=$_SESSION['amountf'];
$rand = rand(0000001,9999999);
$invoice_no=$idd.$rand;
$urls="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];			
$query="update register_e_wallet set amount=(amount+$amount) where user_id='".$idd."'";
mysqli_query($GLOBALS["___mysqli_ston"], "insert into credit_debit values(NULL,'$invoice_no','$idd','$amount','0','0','$idd','$idd','$date','Add Fund','Add Fund','Add Fund','Add Fund','$invoice_no','','0','Activation Wallet','CURRENT_TIMESTAMP','$urls','','','')");	
$res=mysqli_query($GLOBALS["___mysqli_ston"], $query) or die("Error");*/
$msg="Request Added Successfully !";
if($res){
 header("location:add_fund1.php?msg=$msg");
}
?>
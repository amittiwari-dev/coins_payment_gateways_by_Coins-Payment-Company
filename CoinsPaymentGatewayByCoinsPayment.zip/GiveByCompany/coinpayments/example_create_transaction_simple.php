<?php
/*
	CoinPayments.net API Example
	Copyright 2014-2018 CoinPayments.net. All rights reserved.	
	License: GPLv2 - http://www.gnu.org/licenses/gpl-2.0.txt
*/
	require('./coinpayments.inc.php');
	$cps = new CoinPaymentsAPI();
	$cps->Setup('488051CD9735b9575eD25a729a4E3B39a684408C78F8c4f8c2AE6861f64f0e2F', '87162ff0e39a5a9c2f2b13a01ba146c56366b07ab01ad6b79b8c1da7bfe7d73f');

	$result = $cps->CreateTransactionSimple(10.00, 'USDT.TRC20', 'USDT.TRC20', 'your_buyers_email@email.com', '', 'ipn_url');
	if ($result['error'] == 'ok') {
		$le = php_sapi_name() == 'cli' ? "\n" : '<br />';
		print 'Transaction created with ID: '.$result['result']['txn_id'].$le;
		print 'Buyer should send '.sprintf('%.08f', $result['result']['amount']).' BTC'.$le;
		print 'Status URL: '.$result['result']['status_url'].$le;
	} else {
		print 'Error: '.$result['error']."\n";
	}

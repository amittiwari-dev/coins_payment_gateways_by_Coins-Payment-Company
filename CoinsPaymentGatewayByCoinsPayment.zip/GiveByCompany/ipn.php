<?php
include("../lib/config.php");

// $fp = fopen('response.txt', 'a');
// fwrite($fp, '['.date('Y-m-d h:i:s').'] '.json_encode($_REQUEST)."\n");
// fclose($fp);

	 // Fill these in with the information from your CoinPayments.net account. 
    $cp_merchant_id = 'a2149xxxxxxxxxxxxx'; 
    $cp_ipn_secret = ')f2XRxxxxxxxxxxxxxx'; 
    $cp_debug_email = 'payments@helpinghearts.biz'; 
    
    
    function errorAndDie($error_msg) { 
        global $cp_debug_email; 
        if (!empty($cp_debug_email)) { 
            $report = 'Error: '.$error_msg."\n\n"; 
            $report .= "POST Data\n\n"; 
            foreach ($_POST as $k => $v) { 
                $report .= "|$k| = |$v|\n"; 
            } 
            mail($cp_debug_email, 'CoinPayments IPN Error', $report); 
        } 
        die('IPN Error: '.$error_msg); 
    } 

    if (!isset($_POST['ipn_mode']) || $_POST['ipn_mode'] != 'hmac') { 
        errorAndDie('IPN Mode is not HMAC'); 
    } 

    if (!isset($_SERVER['HTTP_HMAC']) || empty($_SERVER['HTTP_HMAC'])) { 
        errorAndDie('No HMAC signature sent.'); 
    } 

    $request = file_get_contents('php://input'); 
    if ($request === FALSE || empty($request)) { 
        errorAndDie('Error reading POST data'); 
    } 

    if (!isset($_POST['merchant']) || $_POST['merchant'] != trim($cp_merchant_id)) { 
        errorAndDie('No or incorrect Merchant ID passed'); 
    } 

    $hmac = hash_hmac("sha512", $request, trim($cp_ipn_secret)); 
    if (!hash_equals($hmac, $_SERVER['HTTP_HMAC'])) { 
    //if ($hmac != $_SERVER['HTTP_HMAC']) { <-- Use this if you are running a version of PHP below 5.6.0 without the hash_equals function 
        errorAndDie('HMAC signature does not match'); 
    } 
     
    // HMAC Signature verified at this point, load some variables. 

    $txn_id = $_POST['txn_id']; 
    $item_name = $_POST['item_name']; 
    $item_number = $_POST['item_number']; 
    $amount1 = floatval($_POST['amount1']); 
    $amount2 = floatval($_POST['amount2']); 
    $currency1 = $_POST['currency1']; 
    $currency2 = $_POST['currency2']; 
    $status = intval($_POST['status']); 
    $status_text = $_POST['status_text']; 

    $received_confirms = $_POST['received_confirms'];


    $callback = json_encode($_POST);
 

    mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO coinpayment_ipn SET txn_id = '".$txn_id."', status_code = '".$status."', status_text = '".$status_text."', ipn_data = '".$callback."', received_confirms = '".$received_confirms."'");


    //These would normally be loaded from your database, the most common way is to pass the Order ID through the 'custom' POST field. 
    $data = mysqli_fetch_assoc(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM coinpayment_invest WHERE txn_id = '".$txn_id."'"));
    $data1 = mysqli_fetch_assoc(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM coinpayment WHERE txn_id = '".$txn_id."'"));

    if(count($data)){
    	$order_currency = $data['currency1']; 
    	$order_total = $amount1; 
    	$package_id = $data['package_id']; 
    	$payment_mode = 'Activation'; 
    }

  if(count($data1)){
    	$order_currency = $data1['currency1']; 
    	$order_total = $amount1; 
    	$payment_mode = 'Add Fund'; 
    }

    //depending on the API of your system, you may want to check and see if the transaction ID $txn_id has already been handled before at this point 

    // Check the original currency to make sure the buyer didn't change it. 
    if ($currency1 != $order_currency) { 
        errorAndDie('Original currency mismatch!'); 
    }     
     
    // Check amount against order total 
   /* if ($amount1 < $order_total) { 
        errorAndDie('Amount is less than order total!'); 
    } */
   	
    

    if ($status >= 100 || $status == 2) { 
        // payment is complete or queued for nightly payout, success 
       
        if($payment_mode=='Add Fund'){
         $total_amount = number_format($order_total); 
       mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment SET callback = '".$callback."', status = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$txn_id."' ");
        $idds = $data1['user_id'];    
         
         $urls="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
        $wtype='Activation Wallet';
         $rand = $txn_id;   
         
mysqli_query($GLOBALS["___mysqli_ston"],"INSERT INTO `register_e_wallet_history` (`payment_id`,`user_id`,`amount`,`remarks`,`date`) VALUES('$rand','".trim($idds)."','".trim($total_amount)."','Crypto Funds','".date('Y-m-d')."')");
               
 mysqli_query($GLOBALS["___mysqli_ston"], "update register_e_wallet set amount=(amount+'".trim($total_amount)."') where user_id='".trim($idds)."'");
                
 mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
','".trim($idds)."', '".trim($total_amount)."', '0', '0', '".trim($idds)."', '123456', '".date('Y-m-d')."', 'Fund Deposit',  'Bulk Bonus', 'Fund Credited By Admin','Fund Credited By Admin', '$rand', 'Crypto Funds', '0', '$wtype', CURRENT_TIMESTAMP, '$urls')");          
            
        }
        
        if($payment_mode=='Activation'){
        
        mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment_invest SET callback = '".$callback."', status = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$txn_id."' ");
        $idd = $data['user_id'];
       
           global $mxDb;
            
            $userdetails=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from user_registration_temp where user_id='".$idd."' and  txn_id = '".$txn_id."'  "));
                      
            $date=date('Y-m-d');
            $total_amount = number_format($order_total);
            $urls="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	        $payment_type='Crypto';
            $ewallet_table='Crypto'; 
            $ewallet_table1='Crypto';
            $ewallet_a_table=0;
            $package=1;
            $user_id=$userdetails['user_id'];
            $username=$userdetails['username'];
            $_SESSION['newuserid']=$user_id;
            
        $numcountsa=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select id from user_registration where username='".$username."' "));
         if($numcountsa==0){
          if(1==1){
			$numcount1=0;
		    $numcount=0;
	        $numcount=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select id from user_registration where ref_id='".$userdetails['ref_id']."'"));
	        $numcount1=$numcount+1;
	        
	        $resultings=0;
            $resultings = mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM user_registration WHERE ref_id='".$userdetails['ref_id']."'"));
            $resultings1=$resultings+1;
            
            
               $newuser_rank_name   = "Paid user";
			  $newdesignation      = "Paid user";
               $kyc_status=0;
			
			
                       $insert_array = array(
						'user_id'			=>	$userdetails['user_id'],
						'ref_id'            =>	$userdetails['ref_id'],
						'dob'				=>	$userdetails['dob'], 
						'zipcode'			=>	$userdetails['zipcode'], 
						'nom_id'			=>	$userdetails['nom_id'],
						'username'			=>	$userdetails['username'],
						'password'			=>	$userdetails['password'],
						'first_name'		=>	$userdetails['first_name'],
						'last_name'			=>	$userdetails['last_name'],
						'email'				=>	$userdetails['email'],
						'country'			=>	$userdetails['country'],
						'admin_status'		=>	"0",
						'user_status'		=>	"0",
						'swift_code'		=>	$userdetails['swift_code'],
						'registration_date'	=>	$date,
						'activation_date'	=>	$date,
						'designation'		=>	$newdesignation,
						'user_rank_name'	=>	$newuser_rank_name,
						't_code'			=>	$userdetails['t_code'], 
						'state'				=>	$userdetails['state'], 
						'city'				=>	$userdetails['city'], 
						'telephone'			=>	$userdetails['telephone'], 
						'address'			=>	$userdetails['address'], 
						'user_plan'			=>	$package,
						'id_card'			=>	'NRIC', 
						'id_no'				=>	$userdetails['id_no'], 
						'sex'				=>	$userdetails['sex'], 
						'dob' 				=>	$userdetails['dob'],
						'referral_code'     =>  $refer_code,
						'account_type'     =>   $userdetails['account_type'],
						'main_id'     =>        $user_id,
						'ref_count'			=>	$numcount1,
						'autoship_status'	=>	'0',
						'autoship_date'	    =>	$date_auto,
						'entity_type'	    =>	$userdetails['entity_type'],
						'kyc_status'	    =>	$userdetails['kyc_status'],
						'owner_id'	    =>	$userdetails['owner_id']
					);
					
					if($mxDb->insert_record('user_registration', $insert_array))
					{
					   mysqli_query($GLOBALS["___mysqli_ston"], "insert into final_e_wallet values(NULL,'".$userdetails['user_id']."','0','0')");
			               mysqli_query($GLOBALS["___mysqli_ston"], "insert into register_e_wallet values(NULL,'".$userdetails['user_id']."','0','0')");
			               mysqli_query($GLOBALS["___mysqli_ston"], "insert into wealth_creator_e_wallet values(NULL,'".$userdetails['user_id']."','0','0')");

			$nom=$userdetails['ref_id'];
			$l=1;
			while($nom!='cmp'){
		    if($nom!='cmp'){
				mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `matrix_downline` (`down_id`, `income_id`, `level`, `leg`, `group_type`, `l_date`, `status`) VALUES ('".$userdetails['user_id']."', '$nom', '$l', '0', '0', '$date', '0')");
				$l++;
			$selectnompos=mysqli_query($GLOBALS["___mysqli_ston"],"select ref_id from user_registration where user_id='$nom' ");
			$fetchnompos=mysqli_fetch_array($selectnompos);
			$nom=$fetchnompos['ref_id'];
			}
		   }

	$upl2=mysqli_query($GLOBALS["___mysqli_ston"], "select * from id_proof_list_temp where user_id='".$userdetails['user_id']."'");
        $uploadtype=mysqli_fetch_array($upl2);
        $uploadtypenom=mysqli_num_rows($upl2);
        if($uploadtypenom>0){
        $insert2_array1 = array(
                    'user_id'			=>$uploadtype['user_id'],
                    'id_proof'           =>	$uploadtype['id_proof'],
                    'id_number'			=>	$uploadtype['id_number'],
                    'id_image'			=>	$uploadtype['id_image'],
                    'date'			=>	$uploadtype['date'],
                    'status'		=>	0
			);
		 $mxDb->insert_record('id_proof_list', $insert2_array1);
        }
		 


		    $nom=$userdetails['nom_id'];
		    
		    $pack=$pckname .' Entry';
		    $byer=$userdetails['user_id'].' Entry by '.$payuserid;
		    
		    	$comm=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from status_maintenance where id='".$package."'"));

		       $ewr=$comm['name'];
				$newuser_rank_name   =$comm['member_name'];
				$packid=$comm['id'];
	          	$packuserid	=$userdetails['user_id'];
				$rand = rand(0000001,9999999);
				$invoice_no=$packuserid.$rand;
				$lfid="LJ".$packuserid.$rand;
				
		    
		    
            $insert_array_cr = array(
						'transaction_no'	 => $txn_id,
						'user_id'            =>	$payuserid,
						'credit_amt'		 =>	0, 
						'debit_amt'			 =>	$total_amount, 
						'admin_charge'		 =>	0,
						'receiver_id'		 =>	$userdetails['user_id'],
						'sender_id'			=>	$payuserid,
						'receive_date'		=>	$date,
						'ttype'		    	=>	$pack,
						'TranDescription'	=>	$byer,
						'Cause'		    	=>	$package,
						'Remark'		    =>	'Active Package',
						'invoice_no'		=>	 $invoice_no,
						'status'	        =>	 0,
						'ewallet_used_by'	=>	$payment_type,
						'ts'            	=>	$datetime,
						'current_url'		=>	$urls
					);
			$mxDb->insert_record('credit_debit', $insert_array_cr);
		}
		
		   
            // $packprice= $total_amount;
                                    			  	
		   	$comm=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from status_maintenance where id='".$package."'"));
		   	
				$sponsor_benifit_bonus=$comm['sponsor_commission'];
				
			//	$pb=$comm['pb'];
			
				
				$it_array2 = array(
				    'user_id'  => $packuserid,
				    'package'  => $packid,
				    'amount'  => $total_amount,
				    'pay_type'  => $payment_type,
				    'pin_no'  => '',
				    'transaction_no'  => $txn_id,
				    'date'  => $date ,
				    'expire_date'  => '',
				    'remark'  => 'Package Purchase',
				    'ts'  => $datetime,
				    'status'  => 'Active',
				    'invoice_no'  => $invoice_no,
				    'lifejacket_id'  => $lfid,
				    'username'  => $packuserid,
				    'sponsor'  => $userdetails['ref_id'],
				    'pb'  => '',
				     'cron_date'=>$date,
				    'invest_type'=>'Active Package'
				    );
				
               $mxDb->insert_record('lifejacket_subscription', $it_array2);

             $userid=$userdetails['user_id'];
    
       $ref=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from user_registration where user_id='$userid'"));   

        $ref_id=$ref['ref_id'];
      
$ref_count=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from user_registration where ref_id='$userid' and user_rank_name='Paid user'"));

          if($ref_id!='cmp'){

        autopool($userid, $packid,$date);

commission_unilevel($userid,$lfid,1,1,$date); 

    
          }
            }
  
         }
    //	header("Location:crypto-success.php");     
       // echo "<script language='javascript'>window.location.href='crypto-success.php';</script>";exit;
        }
    } else if ($status < 0) { 
        //payment error, this is usually final but payments will sometimes be reopened if there was no exchange rate conversion or with seller consent 
       
       if($payment_mode=='Add Fund'){
         mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment SET callback = '".$callback."', status = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$txn_id."' ");
        }
       
        if($payment_mode=='Activation'){
         mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment_invest SET callback = '".$callback."', status = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$txn_id."' ");
        }
        
    } else { 
        //payment is pending, you can optionally add a note to the order page 
        
         if($payment_mode=='Add Fund'){
         mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment SET callback = '".$callback."', status = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$txn_id."' ");
         }
        
         if($payment_mode=='Activation'){
         mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE coinpayment_invest SET callback = '".$callback."', status = '".$status."', status_text = '".$status_text."' WHERE txn_id = '".$txn_id."' ");
         }
        
        
    } 
    
function commission_unilevel($userid,$invoice_no,$packages,$i,$date){
    $date=$date;
	$upliners=mysqli_query($GLOBALS["___mysqli_ston"], "select * from matrix_downline$i where down_id='$userid' and level>='1' order by id ");
	while($upline=mysqli_fetch_array($upliners)){
		$income_id=$upline['income_id'];
		$user_level=$upline['level'];
		$comm=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select level$user_level as total from autopool_commission_setup where package_id='".$packages."'"));
		$comm=$comm['total'];
		
		$tot_down=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "select * from matrix_downline$i where income_id='$income_id' and level='$user_level' "));
		
$commrank=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from user_registration where user_id='$income_id' "));
      $planid=$commrank['user_plan'];
		
       if($user_level==1 && $tot_down>=3){
		     $urwallet=$comm;   
		}elseif($user_level==2 && $tot_down>=9){
		     $urwallet=$comm;   
		}elseif($user_level==3 && $tot_down>=27){
		     $urwallet=$comm;   
		}else{
		    $urwallet=0;
		}
		
if(strpos($income_id,"_")){
            $income_idexp = explode("_",$income_id);
            $userId2 = $income_idexp[0];
        }else{
            $userId2 = $income_id;
        }   	
	
		
   $type='Phase '.$i.' Level '.$user_level.' Income';
   $type2='Phase '.$i.' Income';

	if($urwallet>0){
	    $urls="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
		mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount+$urwallet) where user_id='$userId2'");
        $transactionNo = rand(11111111,9999999999);
    	mysqli_query($GLOBALS["___mysqli_ston"], "insert into credit_debit values(NULL,'$transactionNo','$userId2','$urwallet','0','0','$userId2','$userid','$date','$type','$tot_down','$user_level','$type2','$invoice_no','$packages','0','Income Wallet',CURRENT_TIMESTAMP,'$urls')");
  
  if($packages==5 && $user_level==3 && $tot_down>=27){
      $userid=$userId2;
      $packageid=$packages;
      $pool_income=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from autopool_commission_setup where package_id='".$packages."'"));
		$system_wallet=$pool_income['system_wallet'];
		$upgrade_wallet=$pool_income['upgrade_wallet'];
		$register_wallet=$pool_income['register_wallet'];
		$distribution_wallet=$pool_income['distribution_wallet'];
		$childcare_wallet=$pool_income['childcare_wallet'];
		$education_wallet=$pool_income['education_wallet'];
		$hunger_wallet=$pool_income['hunger_wallet'];
		$livegood_wallet=$pool_income['livegood_wallet'];
		$lifewave_wallet=$pool_income['lifewave_wallet'];
		$company_wallet=$pool_income['company_wallet'];
		
		   mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$upgrade_wallet) where user_id='$userid'");
        
       /*  mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$upgrade_wallet', '0', '$userid', '123456', '$date', 'Subtraction for Phase $packageid',  '$upgrade_wallet', '0','Subtraction for Phase $packageid', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
        */
        
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$childcare_wallet', '0', '123456', '$userid', '$date', 'Child Care Fund',  '$childcare_wallet', '0','Child Care', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$eduction_wallet', '0', '123456', '$userid', '$date', 'Education Fund',  '$eduction_wallet', '0','Education', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$hunger_wallet', '0', '123456', '$userid', '$date', 'Hunger Fund',  '$hunger_wallet', '0','Hunger', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
                        
        mysqli_query($GLOBALS["___mysqli_ston"], "update childcare_e_wallet set amount=(amount+$childcare_wallet) where user_id='123456'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update education_e_wallet set amount=(amount+$eduction_wallet) where user_id='123456'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update hunger_e_wallet set amount=(amount+$hunger_wallet) where user_id='123456'");
      
/*       mysqli_query($GLOBALS["___mysqli_ston"], "update  system_e_wallet set amount=(amount+$system_wallet) where user_id='123456'");
       mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$system_wallet) where user_id='$userid'");
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$system_wallet', '0', '123456', '$userid', '$date', 'System Fee',  '$system_wallet', '0','15', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
      */
  
      
  }
  
if($user_level==3 && $tot_down==27 && $packages==1){
package_upgrade($userId2,2,$date);
}


if($user_level==3 && $tot_down==27 && $packages==2){
package_upgrade($userId2,3,$date);
}  


if($user_level==3 && $tot_down==27 && $packages==3){
package_upgrade($userId2,4,$date);
}  


if($user_level==3 && $tot_down==27 && $packages==4){
package_upgrade($userId2,5,$date);
}         
         
         
if($userId2!='123456'){  
if($user_level==3 && $tot_down==27 && $packages==1){
stage1($userId2,$date,$invoice_no);
commission_unilevel($userId2,$invoice_no,2,2,$date); 
}


if($user_level==3 && $tot_down==27 && $packages==2){
stage2($userId2,$date,$invoice_no);
commission_unilevel($userId2,$invoice_no,3,3,$date); 
}  


if($user_level==3 && $tot_down==27 && $packages==3){
stage3($userId2,$date,$invoice_no);
commission_unilevel($userId2,$invoice_no,4,4,$date); 
}  


if($user_level==3 && $tot_down==27 && $packages==4){
stage4($userId2,$date,$invoice_no);
commission_unilevel($userId2,$invoice_no,5,5,$date); 
}  

}
  
  	}		
	}
}

function package_upgrade($userid,$packageid,$date){

    $comm=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from status_maintenance where id='$packageid'"));
    $amount=$comm['amount'];
    $packageid=$comm['id'];
     $pckname=$comm['name'];
   
    $rand = rand(0000000001,9000000000);
    $start=$date;
    $end = $date;
    $ref=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from user_registration where user_id='$userid'"));  
    $ewa='final_e_wallet';
	$walls="Income Wallet";
    $type=1;
   if($type==1){
     
      $urls="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
      $pv=$amount;
      $lfid="LJ".$userid.$rand;
	  $invest_id='inv'.$rand;
	  $cron_date1=$date;
	  
        $q1=mysqli_query($GLOBALS["___mysqli_ston"],"INSERT INTO `user_request`(`user_id`, `investment_id`, `pack_id`, `amount`,`se_amount`,`convert_amt`,`txn_id`, `payment_mode`, `status`,`package`, `investment_start`, `investment_end`, `roi_per`) VALUES ('".$userid."','".$invest_id."','".$packageid."','".$amount."','".$amount."','".$amount."','".$lfid."','$walls','1','$packageid','$start','$end','$roi_per')");
		mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `lifejacket_subscription` (`id`, `user_id`, `package`, `amount`, `pay_type`, `pin_no`, `transaction_no`, `date`, `expire_date`, `remark`, `ts`, `status`, `invoice_no`,`lifejacket_id`,`username`,`sponsor`,`pb`,`invest_type`,`cron_date`) VALUES (NULL, '$userid', '$packageid', '$amount', '$walls', '$password', '$rand', '$start', '$end', '$pckname Entry', CURRENT_TIMESTAMP, 'Active', '$rand','$lfid','".$userid."','".$ref['ref_id']."','$packageid','Active Package','$cron_date1')");	
		mysqli_query($GLOBALS["___mysqli_ston"], "insert into credit_debit (`transaction_no`,`user_id`,`credit_amt`,`debit_amt`,`admin_charge`,`receiver_id`,`sender_id`,`receive_date`,`ttype`,`TranDescription`,`Cause`,`Remark`,`invoice_no`,`product_name`,`status`,`ewallet_used_by`,`current_url`) values('$rand','$userid','0','$amount','0','$userid','$userid','$start','$pckname Entry','Package Purchase by $userid','Package Purchase by $userid ','Active Package','$rand','$packageid','0','$walls','$urls')");
        mysqli_query($GLOBALS["___mysqli_ston"], "update user_registration set user_plan='$packageid' where user_id='$userid'");
        
        $packageids=$packageid-1;
        $pool_income=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from autopool_commission_setup where package_id='".$packageids."'"));
		$system_wallet=$pool_income['system_wallet'];
		$upgrade_wallet=$pool_income['upgrade_wallet'];
		$register_wallet=$pool_income['register_wallet'];
		$distribution_wallet=$pool_income['distribution_wallet'];
		$childcare_wallet=$pool_income['childcare_wallet'];
		$education_wallet=$pool_income['education_wallet'];
		$hunger_wallet=$pool_income['hunger_wallet'];
		$livegood_wallet=$pool_income['livegood_wallet'];
		$lifewave_wallet=$pool_income['lifewave_wallet'];
		$company_wallet=$pool_income['company_wallet'];

        
        if($packageid==2){
            
        mysqli_query($GLOBALS["___mysqli_ston"], "update distribution_e_wallet set amount=(amount+$distribution_wallet) where user_id='123456'");
         mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$distribution_wallet) where user_id='$userid'");
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$distribution_wallet', '0', '123456', '$userid', '$date', 'Distribution Fund',  '$distribution_wallet', '0','Distribution fund for Free Positions to organizations', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
        
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$upgrade_wallet) where user_id='$userid'");
        /*  
         mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$upgrade_wallet', '0', '$userid', '123456', '$date', 'Subtraction for Phase $packageid',  '$upgrade_wallet', '0','Subtraction for Phase $packageid', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
     */
      
/*      mysqli_query($GLOBALS["___mysqli_ston"], "update  system_e_wallet set amount=(amount+$system_wallet) where user_id='123456'");
       mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$system_wallet) where user_id='$userid'");
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$system_wallet', '0', '123456', '$userid', '$date', 'System Fee',  '$system_wallet', '0','15', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
    */  
    
        }
        
        if($packageid==3){
            
       mysqli_query($GLOBALS["___mysqli_ston"], "update distribution_e_wallet set amount=(amount+$distribution_wallet) where user_id='123456'");
               mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$distribution_wallet) where user_id='$userid'");
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '12345', '0', '$distribution_wallet', '0', '123456', '$userid', '$date', 'Distribution Fund',  '$distribution_wallet', '0','Distribution fund for Free Positions to organizations', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
            
       mysqli_query($GLOBALS["___mysqli_ston"], "update register_e_wallet set amount=(amount+$register_wallet) where user_id='$userid'");
       mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$register_wallet) where user_id='$userid'");  
       mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$register_wallet', '0', '$userid', '123456', '$date', 'Register Fund',  '0', '$register_wallet','Register 2 people for free', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
        
     mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '$register_wallet', '0', '0', '$userid', '123456', '$date', 'Register Fund',  '$register_wallet', '0','Register 2 people for free', '$rand', '$packageids', '0', 'Activation Wallet', CURRENT_TIMESTAMP, '$urls')");
            
       
      mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$upgrade_wallet) where user_id='$userid'");
        /*    mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$upgrade_wallet', '0', '$userid', '123456', '$date', 'Subtraction for Phase $packageid',  '$upgrade_wallet', '0','Subtraction for Phase $packageid', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
     
        */
      
/*  mysqli_query($GLOBALS["___mysqli_ston"], "update  system_e_wallet set amount=(amount+$system_wallet) where user_id='123456'");
       mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$system_wallet) where user_id='$userid'");
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$system_wallet', '0', '123456', '$userid', '$date', 'System Fee',  '$system_wallet', '0','15', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
      
    */  
        
        }
        
        if($packageid==4){
            
            
            
  
        
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$upgrade_wallet) where user_id='$userid'");
        
         /*mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$upgrade_wallet', '0', '$userid', '123456', '$date', 'Subtraction for Phase $packageid',  '$upgrade_wallet', '0','Subtraction for Phase $packageid', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
        */
        
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$childcare_wallet', '0', '123456', '$userid', '$date', 'Child Care Fund',  '$childcare_wallet', '0','Child Care', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$eduction_wallet', '0', '123456', '$userid', '$date', 'Education Fund',  '$eduction_wallet', '0','Education', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$hunger_wallet', '0', '123456', '$userid', '$date', 'Hunger Fund',  '$hunger_wallet', '0','Hunger', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$company_wallet', '0', '123456', '$userid', '$date', ' Wealth Creator 1 Entry',  '$company_wallet', '0',' 2 Year Monthly Fee OR Admin', '$rand', '$packageids', '0', 'Company Wallet', CURRENT_TIMESTAMP, '$urls')");        
                                    
       mysqli_query($GLOBALS["___mysqli_ston"], "update user_registration set rank_royalty='1' where user_id='$userid'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update wealth_creator_e_wallet set amount=(amount+$company_wallet) where user_id='$userid'");                           
        
        
        mysqli_query($GLOBALS["___mysqli_ston"], "update childcare_e_wallet set amount=(amount+$childcare_wallet) where user_id='123456'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update education_e_wallet set amount=(amount+$eduction_wallet) where user_id='123456'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update hunger_e_wallet set amount=(amount+$hunger_wallet) where user_id='123456'");
        
       mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$childcare_wallet) where user_id='$userid'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$eduction_wallet) where user_id='$userid'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$hunger_wallet) where user_id='$userid'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$company_wallet) where user_id='$userid'");


        
       // mysqli_query($GLOBALS["___mysqli_ston"], "update company_e_wallet set amount=(amount+$company_wallet) where user_id='123456'");
       
       
/*      mysqli_query($GLOBALS["___mysqli_ston"], "update  system_e_wallet set amount=(amount+$system_wallet) where user_id='123456'");
       mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$system_wallet) where user_id='$userid'");
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$system_wallet', '0', '123456', '$userid', '$date', 'System Fee',  '$system_wallet', '0','15', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
  */
       
            
        }
        
        if($packageid==5){
            
           mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$upgrade_wallet) where user_id='$userid'");
        
       /*  mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$upgrade_wallet', '0', '$userid', '123456', '$date', 'Subtraction for Phase $packageid',  '$upgrade_wallet', '0','Subtraction for Phase $packageid', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
        */
        
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$childcare_wallet', '0', '123456', '$userid', '$date', 'Child Care Fund',  '$childcare_wallet', '0','Child Care', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$eduction_wallet', '0', '123456', '$userid', '$date', 'Education Fund',  '$eduction_wallet', '0','Education', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$hunger_wallet', '0', '123456', '$userid', '$date', 'Hunger Fund',  '$hunger_wallet', '0','Hunger', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
            
            
        
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '123456', '0', '$company_wallet', '0', '123456', '$userid', '$date', ' Company Fund',  '$company_wallet', '0',' Affiliation & Product for 12 months', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");        
                                    
                        
        mysqli_query($GLOBALS["___mysqli_ston"], "update childcare_e_wallet set amount=(amount+$childcare_wallet) where user_id='123456'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update education_e_wallet set amount=(amount+$eduction_wallet) where user_id='123456'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update hunger_e_wallet set amount=(amount+$hunger_wallet) where user_id='123456'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update company_e_wallet set amount=(amount+$company_wallet) where user_id='123456'");
        
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$childcare_wallet) where user_id='$userid'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$eduction_wallet) where user_id='$userid'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$hunger_wallet) where user_id='$userid'");
        mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$company_wallet) where user_id='$userid'");
        
/*       mysqli_query($GLOBALS["___mysqli_ston"], "update  system_e_wallet set amount=(amount+$system_wallet) where user_id='123456'");
       mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount-$system_wallet) where user_id='$userid'");
mysqli_query($GLOBALS["___mysqli_ston"], "INSERT INTO `credit_debit` (`id`, `transaction_no`, `user_id`, `credit_amt`, `debit_amt`, `admin_charge`, `receiver_id`, `sender_id`, `receive_date`, `ttype`, `TranDescription`, `Cause`, `Remark`, `invoice_no`, `product_name`, `status`, `ewallet_used_by`, `ts`, `current_url`) VALUES (NULL, '$rand
', '$userid', '0', '$system_wallet', '0', '123456', '$userid', '$date', 'System Fee',  '$system_wallet', '0','15', '$rand', '$packageids', '0', 'Income Wallet', CURRENT_TIMESTAMP, '$urls')");
  */
      
        }
        
      

        
}

}

function spill($sponserid,$i){
    global $nom_id1,$lev;
    foreach($sponserid as $key => $val){
        $query1="select * from matrix_downline$i where income_id='$val' and level='1' order by id asc";
        $result1=mysqli_query($GLOBALS["___mysqli_ston"], $query1);
        $num_ro1[]=mysqli_num_rows($result1);
        while($row=mysqli_fetch_array($result1)){
            $rclid1[]=$row['down_id'];
        }
    }
    foreach($num_ro1 as $key11 => $valu){
        if($valu < 3){
            $key1=$key11;
            break;
        }
    }
    switch ($valu){
        case '0':
        $nom_id1=$sponserid[$key1];
        break;
        case '1':
        $nom_id1=$sponserid[$key1];
        break;
        case '2':
        $nom_id1=$sponserid[$key1];
        break;
        case '3':
        if(!empty($nom_id1)){
            break;
        }
        spill($rclid1,$i);
    }
    return $nom_id1;
}

function autopool($userid,$package_id,$date) {
    $mainowner = $userid;

        if ($mainowner != '') {
        global $mxDb;
        $date = date("Y-m-d");
        $result = mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select * from user_registration where user_id='$mainowner'"));
        $insert_array = array('user_id' => $mainowner, 'ref_id' => $result['ref_id'], 'nom_id' => $result['nom_id'], 'activation_date' => $date, 'owner_id' => $mainowner);
        $mxDb->insert_record('user_registration_pool', $insert_array);
    }
          
      $upliners=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT user_id FROM `user_registration_pool` order by id asc ");
        while($upline=mysqli_fetch_array($upliners)){
        $user_upline=$upline['user_id'];
        $data_count=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM `user_registration_pool` WHERE nom_id1='$user_upline' "));
        if($data_count<3){
        $user_upline1=$user_upline;
        break;
        }
        } 
          
         $ref_id123 = array();
           $ref_id123[]=$user_upline1;
            $nom_id=spill($ref_id123,1);
            $nom=$nom_id;
            	mysqli_query($GLOBALS["___mysqli_ston"],"update user_registration_pool set nom_id1='$nom',pack_id='$package_id' where user_id='$mainowner'");
            $l=1;
    		while($nom!='cmp' &&  $l<4){
    		    if($nom!='cmp' && $nom!=''){
    		        
        			mysqli_query($GLOBALS["___mysqli_ston"], "insert into matrix_downline1 set down_id='$mainowner', income_id='$nom', l_date='$date', status=0, level='$l'");
        			$l++;
    
        			$selectnompos=mysqli_query($GLOBALS["___mysqli_ston"],"select income_id from matrix_downline1 where down_id='$nom' ");
            			$fetchnompos=mysqli_fetch_array($selectnompos);
            			$nom=$fetchnompos['income_id'];
        			
        			if($nom==''){
        			    break;
        			}
    			}
        	}
        	
       
    
  }

function stage1($userid,$date) {
    $mainowner = $userid;
    
         $upliners=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT user_id FROM `user_registration_pool` order by id asc  ");
        while($upline=mysqli_fetch_array($upliners)){
        $user_upline=$upline['user_id'];
        $data_count=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM `user_registration_pool` WHERE nom_id2='$user_upline' "));
        if($data_count<3){
        $user_upline2=$user_upline;
        break;
        }
        } 
         
         $ref_id123 = array();
           $ref_id123[]=$user_upline2;
            $nom_id=spill($ref_id123,2);
            $nom=$nom_id;
            	mysqli_query($GLOBALS["___mysqli_ston"],"update user_registration_pool set nom_id2='$nom' where user_id='$mainowner'");
         
            $l=1;
    		while($nom!='cmp' &&  $l<4){
    		    if($nom!='cmp' && $nom!=''){
    		        
        			mysqli_query($GLOBALS["___mysqli_ston"], "insert into matrix_downline2 set down_id='$mainowner', income_id='$nom', l_date='$date', status=0, level='$l'");
        			$l++;
    
        			$selectnompos=mysqli_query($GLOBALS["___mysqli_ston"],"select income_id from matrix_downline2 where down_id='$nom' ");
            			$fetchnompos=mysqli_fetch_array($selectnompos);
            			$nom=$fetchnompos['income_id'];
        			
        			if($nom==''){
        			    break;
        			}
    			}
        	}
        	
      

 
    
  }

function stage2($userid,$date) {
    $mainowner = $userid;
    
     $upliners=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT user_id FROM `user_registration_pool` order by id asc  ");
        while($upline=mysqli_fetch_array($upliners)){
        $user_upline=$upline['user_id'];
        $data_count=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM `user_registration_pool` WHERE nom_id3='$user_upline' "));
        if($data_count<3){
        $user_upline3=$user_upline;
        break;
        }
        } 
    
         $ref_id123 = array();
           $ref_id123[]=$user_upline3;
            $nom_id=spill($ref_id123,3);
            $nom=$nom_id;
            	mysqli_query($GLOBALS["___mysqli_ston"],"update user_registration_pool set nom_id3='$nom' where user_id='$mainowner'");
        
            $l=1;
    		while($nom!='cmp' &&  $l<4){
    		    if($nom!='cmp' && $nom!=''){
    		        
        			mysqli_query($GLOBALS["___mysqli_ston"], "insert into matrix_downline3 set down_id='$mainowner', income_id='$nom', l_date='$date', status=0, level='$l'");
        			$l++;
    
        			$selectnompos=mysqli_query($GLOBALS["___mysqli_ston"],"select income_id from matrix_downline3 where down_id='$nom' ");
            			$fetchnompos=mysqli_fetch_array($selectnompos);
            			$nom=$fetchnompos['income_id'];
        			
        			if($nom==''){
        			    break;
        			}
    			}
        	}
        	
    
  }
  
function stage3($userid,$date) {
    $mainowner = $userid;

   $upliners=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT user_id FROM `user_registration_pool` order by id asc  ");
        while($upline=mysqli_fetch_array($upliners)){
        $user_upline=$upline['user_id'];
        $data_count=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM `user_registration_pool` WHERE nom_id4='$user_upline' "));
        if($data_count<3){
        $user_upline4=$user_upline;
        break;
        }
        } 

         $ref_id123 = array();
           $ref_id123[]=$user_upline4;
            $nom_id=spill($ref_id123,4);
            $nom=$nom_id;
            	mysqli_query($GLOBALS["___mysqli_ston"],"update user_registration_pool set nom_id4='$nom' where user_id='$mainowner'");
         
            $l=1;
    		while($nom!='cmp' &&  $l<4){
    		    if($nom!='cmp' && $nom!=''){
    		        
        			mysqli_query($GLOBALS["___mysqli_ston"], "insert into matrix_downline4 set down_id='$mainowner', income_id='$nom', l_date='$date', status=0, level='$l'");
        			$l++;
    
        			$selectnompos=mysqli_query($GLOBALS["___mysqli_ston"],"select income_id from matrix_downline4 where down_id='$nom' ");
            			$fetchnompos=mysqli_fetch_array($selectnompos);
            			$nom=$fetchnompos['income_id'];
        			
        			if($nom==''){
        			    break;
        			}
    			}
        	}
        	
    
  }

function stage4($userid,$date) {
    $mainowner = $userid;
      $upliners=mysqli_query($GLOBALS["___mysqli_ston"], "SELECT user_id FROM `user_registration_pool` order by id asc  ");
        while($upline=mysqli_fetch_array($upliners)){
        $user_upline=$upline['user_id'];
        $data_count=mysqli_num_rows(mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM `user_registration_pool` WHERE nom_id5='$user_upline' "));
        if($data_count<3){
        $user_upline5=$user_upline;
        break;
        }
        } 
    
         $ref_id123 = array();
           $ref_id123[]=$user_upline5;
            $nom_id=spill($ref_id123,5);
            $nom=$nom_id;
            	mysqli_query($GLOBALS["___mysqli_ston"],"update user_registration_pool set nom_id5='$nom' where user_id='$mainowner'");
            	
         	
            $l=1;
    		while($nom!='cmp' &&  $l<4){
    		    if($nom!='cmp' && $nom!=''){
    		        
        			mysqli_query($GLOBALS["___mysqli_ston"], "insert into matrix_downline5 set down_id='$mainowner', income_id='$nom', l_date='$date', status=0, level='$l'");
        			$l++;
    
        			$selectnompos=mysqli_query($GLOBALS["___mysqli_ston"],"select nom_id5 from user_registration_pool where user_id='$nom' ");
            			$fetchnompos=mysqli_fetch_array($selectnompos);
            			$nom=$fetchnompos['nom_id5'];
        			
        			if($nom==''){
        			    break;
        			}
    			}
        	}
        
    
  }
	
